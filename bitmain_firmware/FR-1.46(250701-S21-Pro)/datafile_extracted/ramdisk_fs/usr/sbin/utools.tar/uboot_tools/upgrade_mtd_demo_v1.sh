#!/bin/sh

SCRIPT_NAME="upgrade_mtd_demo.sh"
VERSION="v1.1"

total_copys=
copies_in_part=
img_path=
mtd_path=
upgrade_dst_device=
upgrade_src_file=
mtd_dev=
write_size=
erase_size=
mtd_size=
img_size=
backup_path="/tmp"
BOOT_LOADER_PART="bootloader"
mtd_dev_char=
mtd_dev_block=

data_pattern1="0xFFFF"

Introduce() {
	echo "upgrade_mtd_demo.sh provide a sample way to upgrade mtd partitions. it relies on
	flash_erase and dd tool. Before running it, must be ensure that these tools in the
	system.

	AML mtd partitions usually can be divided into two types.one is boot partition,
	one is other partition. Typically boot partitions include bb1st/bootloader、
	bl2e、bl2x、ddrfip、devfip etc.

	image in boot partitions need to store multiple copies. these boot partitions
	upgrade by upgrade_mtd_demo.sh must be used mtd character device(/dev/mtdx).
	other partitions must be used mtd block device(/dev/mtdblockx)

	boot partitions upgrade method:
	./upgrade_mtd_demo.sh /dev/mtdx image_path copies

	other partitions upgrade method:
	./upgrade_mtd_demo.sh /dev/mtdblockx image_path 1
	"
}

Usage() {
	echo "command format: ./$SCRIPT_NAME parameter1@mtd_path parameter2@img_path parameter3@total_copys"
	echo "total_copys is mean the partition(mtd_path) exist total copy number"
	echo "Note !!!"
	echo "upgrade boot partitions the mtd_path must be a character device(/dev/mtdx),"
	echo "boot part usually contain multiple backups"
	echo "e.g. ./upgrade_mtd_demo.sh /dev/mtd0 /tmp/bootloader.img 8"
	echo "upgrade other partitions the mtd_path must be a block device(/dev/mtdblockx)"
	echo "e.g. ./upgrade_mtd_demo.sh /dev/mtdblock1 /tmp/boot.img 1"
	echo "version: $VERSION"
}

get_mtd_index() {
	local number=$(echo $1 | tr -cd "[0-9]")
	
	echo $number
}

#parameter@mtd_path
get_mtd_dev_char() {
	local mtddev
	if [ -c "$mtd_path" ]; then
		mtddev=$(basename $mtd_path)
	elif [ -b "$mtd_path" ]; then
		local index=$(cat /proc/partitions | awk -v dev="$(basename $mtd_path)" '$4 == dev {print $2}')
		mtddev="mtd$index"
	fi

	echo $mtddev
}

get_mtd_dev_block() {
	local mtddev
	local index
	if [ -c "$mtd_path" ]; then
		index=$(get_mtd_index "$(basename $mtd_path)")
		mtddev="mtdblock$index"

	elif [ -b "$mtd_path" ]; then
		mtddev="$(basename $mtd_path)"
	fi

	echo $mtddev
}

#parameter@mtd_dev_char
get_mtd_writesize() {
	local mtd_device="/sys/class/mtd/$1"
	local writesize=$(cat "$mtd_device/writesize")

	echo $writesize
}

#parameter@mtd_dev_char
get_mtd_erasesize() {
	local erasesize=$(cat /sys/class/mtd/$1/erasesize)

	echo $erasesize
}

#parameter@mtd_dev_char
get_mtd_size() {
    #local size=$(cat /proc/mtd | awk -v filter="$1:" '$4 == mtdblock { print $2 }')
	local size=$(cat /sys/class/mtd/$1/size)

	echo $size
}

get_mtd_blockdevice() {
	local index=$(get_mtd_index $1)
	local mtdblock="/dev/mtdblock$index"

	echo $mtdblock
}

check_dependent_tools_is_exist() {
	#check flash_erase
	if ! which flash_erase >/dev/null; then
		echo "flash_erase tool is not exist"
		exit 1
	fi
}

check_upgrade_bootloader_legal() {
	local mtd_name=$(cat /proc/mtd | awk -v dev="$1:" '$1 == dev {print $4}')

	if [ "$mtd_name" == "bootloader" ]; then
		# check the device is a character device
		if [ ! -c "$mtd_path" ]; then
			echo "the device $mtd_path is not a character device"
			echo "please input mtd character device"
			echo "e.g. ./upgrade_mtd_demo.sh /dev/mtd0 /tmp/bootloader.img 8"
			exit 1
		fi
	fi
}

# mtd character device to mtd block device or
# mtd block device to mtd character device
mtd_char_to_block_device() {
	local mtdblock_dev=$(get_mtd_blockdevice "$mtd_dev_char")

	echo $mtdblock_dev
}

mtd_block_to_char_device() {
	local index=$(cat /proc/partitions | awk -v dev="$mtd_dev_block" '$4 == dev {print $2}')
	local mtdchar="/dev/mtd$index"

	echo $mtdchar
}

check_device_is_busy() {
	local paths="/dev/$mtd_dev_char /dev/$mtd_dev_block"

	for path in $paths; do
		if [ -e "$path" ]; then
			if mountpoint -q "$path"; then
				echo "Error: MTD device $path is Busy."
				exit 1
			fi
		fi
		
	done
}

need_erase_device() {
	if [ -c "$1" ]; then
		return 0
	elif [ -b "$1" ]; then
		return 1
	fi
}

#$1=src_file $2=offset $3=len
NAND_WRITE_PART_CHECK_ILLEGAL() {
	local writesize=$(get_mtd_writesize "$mtd_dev_char")
	local filesize=$(ls -l $1 | awk '{print $5}')
	local filesize_align=$((filesize % writesize))
	local offset_align=$(($2 % writesize))
	local len_align=$(($3 % writesize))

	if [ $offset_align -ne 0 -o $len_align -ne 0 -o $filesize_align -ne 0 ]; then
		echo "file@$1 offset@$2 len@$len is not align to writesize@$writesize"
		exit 1
	fi
}

# $1=to_fill_file $2=fill_data_len
fill_data_pattern0() {
	local i=0
	local len=$2

	while [ $i -lt $((len - 1)) ]; do
		printf '\x55\xaa' >> $1
		i=$((i + 2))
	done

	if [ $i -ne $len ]; then
		printf '\x55' >> $1
	fi

	echo "the image size is $(ls -l $1 | awk '{print $5}')  (B), need to append $len (B) 0x55AA to up align writesize"
}

fill_data_pattern1() {
	local i=0
	local len=$2

	while [ $i -lt $len ]; do
		printf '\xFF' >> $1
		i=$((i + 1))
	done

	echo "the image size is $(ls -l $1 | awk '{print $5}')  (B), need to append $len (B) 0xFF to up align writesize"
}

# $1=to_fill_file $2=fill_data_len
fill_file() {
	local filepath=$1
	local len=$2

	fill_data_pattern1 "$filepath" $len
}

#$1=src_file $2=dst_file $3=offset $4=len
#note! offset and len unit is pagesize
nand_write() {

	local src_file=$1
	local dst_file=$2
	local offset=$3
	local len=$4

	local writesize=$(get_mtd_writesize "$mtd_dev_char")
	local filesize=$(ls -l $src_file | awk '{print $5}')
	local size=$((len *writesize))
	local seek=$offset
	local count=$len

	if [ $size -gt $filesize ]; then
		local fill_size=$((size - filesize))
		local tmp_src_file="$backup_path/tmp_src_file.align.img"
		cp $src_file $tmp_src_file
		fill_file $tmp_src_file $fill_size
		if ! dd if=$tmp_src_file of=$dst_file bs=$writesize count=$count seek=$seek conv=notrunc; then
			echo "nand write $dst_file offset@$offset len@$len failed"
			rm $tmp_src_file
			return 1
		fi
		rm $tmp_src_file
		return 0
	else
		if ! dd if=$src_file of=$dst_file bs=$writesize count=$count seek=$seek conv=notrunc; then
			echo "nand write $dst_file offset@$offset len@$len failed"
			return 1
		fi
		return 0
	fi
}

#$1=src_file $2=dst_file $3=offset $4=len
#note! offset and len unit is pagesize
nand_read() {

	local src_file=$1
	local dst_file=$2
	local offset=$3
	local len=$4

	local skip=$offset
	local count=$len

	local writesize=$(get_mtd_writesize "$mtd_dev_char")

	if ! dd if=$src_file of=$dst_file bs=$writesize count=$count skip=$skip; then
		echo "nand read $src_file offset@$offset len@$len failed"
		return 1
	fi
	return 0
}

#$1=src_file $2=dst_device $3=offset $4=len
nand_write_part() {
		
		NAND_WRITE_PART_CHECK_ILLEGAL "$1" $3 $4
		local src_file="$1"
		local dst_device="$2"
		local offset=$3
		local len=$4
	
		local mtdsize=$(get_mtd_size "$mtd_dev_char")
		local writesize=$(get_mtd_writesize "$mtd_dev_char")
		# offset and len must align to writesize
		local seek_bs_count=$((offset / writesize))
		local write_bs_count=$((len / writesize))
        local verify_file="$backup_path/verify.img"

        if ! nand_write "$src_file" "$dst_device" $seek_bs_count $write_bs_count; then
			echo "Upgrade write $dst_device offset@$offset len@$len failed"
			exit 1
		fi

        # check integrity
		local skip_bs_count=$seek_bs_count

        if ! nand_read "$dst_device" "$verify_file" $skip_bs_count $write_bs_count; then
			echo "verify read $dst_device offset@$offset len@$len failed"
			exit 1
		fi

        # md5sum check
        local original_md5=$(md5sum "$src_file" | cut -d' ' -f1)
        local verify_md5=$(md5sum "$verify_file" | cut -d' ' -f1)

        if [ "$original_md5" == "$verify_md5" ]; then
            echo "Data verification successful, write offset@$offset len@$len pass"
        else
            echo "Error: Data verification failed, write offset@$offset len@$len failed"
            exit 1
        fi
}

#$1=src_file $2=dst_device $3=copy
#@dst_device must be a character device if you upgrade boot partitions,
#           otherwise it must be a block device
nand_write_parts() {

    local i=0
	local src_file="$1"
	local dst_part="$2"
	local copies=$3
	local src_file_align=$backup_path/$(basename $src_file).align

    # calc
	local partsize=$(get_mtd_size "$mtd_dev_char")
	local erasesize=$(get_mtd_erasesize "$mtd_dev_char")
    local copysize=$((partsize / total_copys))
	local blks_per_copy=$((copysize / erasesize))

	local filesize=$(ls -l $src_file | awk '{print $5}')
	local writesize=$(get_mtd_writesize "$mtd_dev_char")
	local file_pages=$((filesize / writesize))
	local file_page_offset=$((filesize % writesize))
	local remain_size_page=0

	if [ $file_page_offset -gt 0 ]; then
		file_pages=$((file_pages + 1))
		remain_size_page=$((writesize - file_page_offset))
	fi
	# create a align up writesize upgrade file
	cp $src_file $src_file_align

	if [ -c $dst_part -o -b $dst_part ]; then
		fill_file $src_file_align $remain_size_page
	else
		echo "don't support device type $dst_part"
	fi
	
	echo "the Upgrade file real size is $(ls -l $src_file_align | awk '{print $5}') (B)"

	local real_write_size=$((file_pages *writesize))
	while [ $i -lt $copies ]; do
        local offset=$((i * copysize))

		if need_erase_device "$dst_part"; then
			if flash_erase "$dst_part" $offset $blks_per_copy; then
				# upgrade copy@i
				nand_write_part "$src_file_align" "$dst_part" $offset $real_write_size
			else
				echo "erase $dst_part offset@$offset len@$(erasesize * blks_per_copy) failed"
			fi
		else
			# upgrade copy@i
			nand_write_part "$src_file_align" "$dst_part" $offset $real_write_size
		fi

		i=$((i + 1))
	done
}

upgrade_mtd_device() {

    # check the device is exist
    if [ ! -e "$upgrade_dst_device" ]; then
        echo "Error: $upgrade_dst_device device not found."
        exit 1
    fi

	#$1=src_file $2=dst_device $3=copy
	nand_write_parts $upgrade_src_file $upgrade_dst_device $copies_in_part

    echo "Upgrade completed."
}

#main 
# get mtdblock device path, upgrade image path, write_offset
mtd_path=$1
img_path=$2
total_copys=$3

# check parameter is whether null
if [ -z "$mtd_path" ] || [ -z "$img_path" ] || [ -z "$total_copys" ]; then
	Introduce
	Usage
	exit 1
fi

upgrade_dst_device="$mtd_path"
upgrade_src_file="$img_path"
copies_in_part=$total_copys
mtd_dev="$(basename ${mtd_path})"
mtd_dev_char="$(get_mtd_dev_char)"
mtd_dev_block="$(get_mtd_dev_block)"

echo "upgrade device path:$upgrade_dst_device"
echo "upgrade src file path:$upgrade_src_file"
echo "$upgrade_dst_device need to upgrade total backups:$copies_in_part"

# check the image is a real file
if [ ! -f "$upgrade_src_file" ]; then
  echo "image not exist：$upgrade_src_file"
  exit 1
fi
#

# check device is Busy
check_device_is_busy

# check flash_erase is exist or not
check_dependent_tools_is_exist

upgrade_mtd_device

exit 0
